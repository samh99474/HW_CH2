package p43;

import java.io.IOException;


public class p43 {
	public static void main(String[] args) throws IOException
	{	
		int []test = {100,20,35,48,56};
		
		for(int i=0;i<test.length;i++)
		{
			System.out.println("��"+(i+1)+ "�ӤH�����ƬO"+test[i]+"��");
		}
		System.out.println("�ҸդH�Ƭ�"+test.length+ "�H");
	}
}
