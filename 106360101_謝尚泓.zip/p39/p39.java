package p39;

import java.io.IOException;


public class p39 {
	public static void main(String[] args) throws IOException
	{	
		int []test = new int[5];
		test[0]=80;
		test[1]=55;
		test[2]=77;
		test[3]=66;
		test[4]=20;
		
		for(int i=0;i<5;i++)
		{
			System.out.println("��"+(i+1)+ "�ӤH�����ƬO"+test[i]+"��");
		}
	}
}
