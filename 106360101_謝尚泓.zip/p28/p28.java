package p28;

import java.io.IOException;

public class p28 {
	public static void main(String[] args) throws IOException
	{	
		int i = 1;
		 do {
			System.out.println("��"+i+ "�����j��");
			i++;
		}while(i<=5);
		 
		System.out.println("�j�鵲��");
	}
}
