package p26;

import java.io.IOException;

public class p26 {
	public static void main(String[] args) throws IOException
	{	
		int i = 1;
		while(i<=5) {
			System.out.println("��"+i+ "�����j��");
			i++;
		}
		System.out.println("�j�鵲��");
	}
}
