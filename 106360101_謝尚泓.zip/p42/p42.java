package p42;

import java.io.IOException;


public class p42 {
	public static void main(String[] args) throws IOException
	{	
		int []test = {100,20,35,48,56};
		
		for(int i=0;i<5;i++)
		{
			System.out.println("��"+(i+1)+ "�ӤH�����ƬO"+test[i]+"��");
		}
	}
}
